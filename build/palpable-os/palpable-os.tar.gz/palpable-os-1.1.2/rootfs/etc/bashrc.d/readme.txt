# /etc/bashrc.d/ is implemented by DietPi to source custom scripts user-wide on interactive bash session starts.
# It works like /etc/profile.d/ but for all interactive bash shells as contained scripts are sourced from /etc/bash.bashrc.
# All files with .sh or .bash endings are sourced.
