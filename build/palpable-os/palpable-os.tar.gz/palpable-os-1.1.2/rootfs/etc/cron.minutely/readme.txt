# /etc/cron.minutely/ is implemented by DietPi and allows to run scripts every chosen amount of minutes.
# Run "dietpi-cron" to enable and configure this feature.
